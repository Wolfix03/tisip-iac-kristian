student_id = "krisan03"
project    = "tisip-iac"
location   = "norwayeast"
